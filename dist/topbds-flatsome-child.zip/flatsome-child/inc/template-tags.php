<?php
/**
 * Hàm dựng HTML dùng chung: icon SVG, thẻ dự án, ô loại hình/khu vực.
 */

defined( 'ABSPATH' ) || exit;

/**
 * Icon SVG nội tuyến (nét theo bộ Lucide), đổi màu theo `color` của phần tử cha.
 */
function tp_icon( $name, $size = 18 ) {
	static $paths = array(
		'search'   => '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
		'pin'      => '<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/>',
		'tag'      => '<path d="M12.6 2.6A2 2 0 0 0 11.2 2H4a2 2 0 0 0-2 2v7.2a2 2 0 0 0 .6 1.4l8.7 8.7a2.4 2.4 0 0 0 3.4 0l6.6-6.6a2.4 2.4 0 0 0 0-3.4Z"/><circle cx="7.5" cy="7.5" r="1.2"/>',
		'building' => '<path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"/><path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2"/><path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2"/><path d="M10 6h4M10 10h4M10 14h4M10 18h4"/>',
		'grid'     => '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/>',
		'arrow'    => '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
		'prev'     => '<path d="m15 18-6-6 6-6"/>',
		'next'     => '<path d="m9 18 6-6-6-6"/>',
		'phone'    => '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2Z"/>',
		'chat'     => '<path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/><path d="M8 12h.01M12 12h.01M16 12h.01"/>',
		'shield'   => '<path d="M20 13c0 5-3.5 7.5-7.7 9a1 1 0 0 1-.6 0C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.2-2.7a1.2 1.2 0 0 1 1.6 0C14.5 3.8 17 5 19 5a1 1 0 0 1 1 1Z"/><path d="m9 12 2 2 4-4"/>',
		'headset'  => '<path d="M3 11h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-5Zm0 0a9 9 0 1 1 18 0m0 0v5a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3Z"/><path d="M21 16v2a4 4 0 0 1-4 4h-5"/>',
		'users'    => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="m16 11 2 2 4-4"/>',
		'calendar' => '<rect width="18" height="18" x="3" y="4" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
		'mail'     => '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-9 5.7a2 2 0 0 1-2 0L2 7"/>',
		'file'     => '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="m9 15 2 2 4-4"/>',
		'area'     => '<path d="M8 3H5a2 2 0 0 0-2 2v3M21 8V5a2 2 0 0 0-2-2h-3M3 16v3a2 2 0 0 0 2 2h3M16 21h3a2 2 0 0 0 2-2v-3"/>',
		'bed'      => '<path d="M2 20v-8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v8"/><path d="M4 10V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v4"/><path d="M12 4v6M2 18h20"/>',
		'download' => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><path d="M12 15V3"/>',
		'key'      => '<circle cx="7.5" cy="15.5" r="5.5"/><path d="m21 2-9.6 9.6M15.5 7.5l3 3L22 7l-3-3"/>',
		'home'     => '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/><path d="M9.5 21v-6h5v6"/>',
		'homes'    => '<path d="M2 21h20"/><path d="M4 21V10l4-3 4 3v11"/><path d="M12 21V10l4-3 4 3v11"/><path d="M7 14h2M15 14h2"/>',
		'map'      => '<path d="M14.1 5.1 9.9 2.9a2 2 0 0 0-1.8 0L3.6 5.2A1 1 0 0 0 3 6.1v14a1 1 0 0 0 1.4.9l3.7-1.9a2 2 0 0 1 1.8 0l4.2 2.1a2 2 0 0 0 1.8 0l4.5-2.3a1 1 0 0 0 .6-.9v-14a1 1 0 0 0-1.4-.9l-3.7 1.9a2 2 0 0 1-1.8 0Z"/><path d="M9 3v16M15 5v16"/>',
		'trees'    => '<path d="M10 10v.2A3 3 0 0 1 8.9 16H5a3 3 0 0 1-1-5.8V10a3 3 0 0 1 6 0Z"/><path d="M7 16v6M13 19v3"/><path d="M12 19h8.3a1 1 0 0 0 .7-1.7L18 14h.3a1 1 0 0 0 .7-1.7L16 9h.2a1 1 0 0 0 .8-1.7L13 3l-1.4 1.5"/>',
		'bulb'     => '<path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"/><path d="M9 18h6M10 22h4"/>',
	);

	if ( ! isset( $paths[ $name ] ) ) {
		return '';
	}

	return sprintf(
		'<svg class="tp-icon tp-icon--%1$s" width="%2$d" height="%2$d" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">%3$s</svg>',
		esc_attr( $name ),
		(int) $size,
		$paths[ $name ]
	);
}

/**
 * Ảnh của bài viết/dự án, có khung giữ chỗ khi chưa có ảnh đại diện.
 */
function tp_post_image( $post_id, $size, $attr = array() ) {
	if ( has_post_thumbnail( $post_id ) ) {
		return get_the_post_thumbnail( $post_id, $size, array_merge( array( 'alt' => get_the_title( $post_id ) ), $attr ) );
	}
	return '<span class="tp-noimg" aria-hidden="true"></span>';
}

/**
 * Tên các mục phân loại của một dự án, nối bằng " | ".
 */
function tp_term_names( $post_id, $taxonomy ) {
	$terms = get_the_terms( $post_id, $taxonomy );
	return $terms && ! is_wp_error( $terms ) ? implode( ' | ', wp_list_pluck( $terms, 'name' ) ) : '';
}

/**
 * Nhãn góc ảnh: Trạng thái (VD: "Đang mở bán"), kèm "Hot" đứng bên cạnh nếu được tick.
 */
function tp_project_badge( $post_id ) {
	$badges = '';
	$status = get_the_terms( $post_id, 'trang_thai' );
	if ( $status && ! is_wp_error( $status ) ) {
		$badges .= '<span class="tp-badge">' . esc_html( $status[0]->name ) . '</span>';
	}
	if ( get_post_meta( $post_id, 'tp_hot', true ) ) {
		$badges .= '<span class="tp-badge tp-badge--hot">Hot</span>';
	}
	return $badges ? '<span class="tp-badges">' . $badges . '</span>' : '';
}

/**
 * Thẻ dự án.
 *
 * @param array $args badge (bool), button (bool), heading (thẻ tiêu đề: h3/h2).
 */
function tp_project_card( $post_id, $args = array() ) {
	$args = wp_parse_args( $args, array( 'badge' => true, 'button' => true, 'heading' => 'h3' ) );
	$tag  = in_array( $args['heading'], array( 'h2', 'h3', 'h4', 'p' ), true ) ? $args['heading'] : 'h3';

	$link     = get_permalink( $post_id );
	$title    = get_the_title( $post_id );
	$location = get_post_meta( $post_id, 'tp_dia_chi', true ) ?: tp_term_names( $post_id, 'khu_vuc' );
	$price    = get_post_meta( $post_id, 'tp_gia', true );
	$products = get_post_meta( $post_id, 'tp_san_pham', true ) ?: tp_term_names( $post_id, 'loai_hinh' );

	ob_start();
	?>
	<article class="tp-card">
		<a class="tp-card__media" href="<?php echo esc_url( $link ); ?>" tabindex="-1" aria-hidden="true">
			<?php
			// Thẻ dự án dùng thẻ p (menu xổ xuống, dự án liên quan cuối trang) không hiện ngay khi tải trang: tải sau, không tranh ưu tiên với ảnh đầu trang.
			echo tp_post_image( $post_id, 'tp-card', 'p' === $tag ? array( 'loading' => 'lazy', 'fetchpriority' => 'low' ) : array() );
			?>
		</a>
		<?php if ( $args['badge'] ) { echo tp_project_badge( $post_id ); } ?>
		<div class="tp-card__body">
			<<?php echo $tag; ?> class="tp-card__title">
				<a href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $title ); ?></a>
			</<?php echo $tag; ?>>
			<?php if ( $location ) : ?>
				<p class="tp-card__row"><?php echo tp_icon( 'pin', 14 ); ?><span><?php echo esc_html( $location ); ?></span></p>
			<?php endif; ?>
			<?php if ( $price ) : ?>
				<p class="tp-card__row tp-card__price"><?php echo tp_icon( 'tag', 14 ); ?><span><?php echo esc_html( $price ); ?></span></p>
			<?php endif; ?>
			<?php if ( $products ) : ?>
				<p class="tp-card__row tp-card__products"><?php echo tp_icon( 'grid', 14 ); ?><span><?php echo esc_html( $products ); ?></span></p>
			<?php endif; ?>
			<?php if ( $args['button'] ) : ?>
				<a class="tp-card__btn" href="<?php echo esc_url( $link ); ?>">Xem chi tiết<span class="screen-reader-text"> <?php echo esc_html( $title ); ?></span> <?php echo tp_icon( 'arrow', 14 ); ?></a>
			<?php endif; ?>
		</div>
	</article>
	<?php
	return ob_get_clean();
}

/**
 * Ô ảnh của một Loại hình / Khu vực, kèm số dự án.
 */
function tp_term_tile( WP_Term $term, $arrow = true ) {
	$image_id = (int) get_term_meta( $term->term_id, 'tp_image_id', true );
	$alt      = $image_id ? get_post_meta( $image_id, '_wp_attachment_image_alt', true ) : '';
	if ( ! $alt ) {
		$alt = 'khu_vuc' === $term->taxonomy ? 'Dự án bất động sản tại ' . $term->name : 'Dự án ' . mb_strtolower( $term->name );
	}
	$image    = $image_id ? wp_get_attachment_image( $image_id, 'tp-tile', false, array( 'alt' => $alt ) ) : '<span class="tp-noimg" aria-hidden="true"></span>';

	return sprintf(
		'<a class="tp-tile" href="%1$s">%2$s<span class="tp-tile__body"><span class="tp-tile__name">%3$s</span><span class="tp-tile__count">%4$s dự án</span></span>%5$s</a>',
		esc_url( get_term_link( $term ) ),
		$image,
		esc_html( $term->name ),
		esc_html( number_format_i18n( $term->count ) ),
		$arrow ? '<span class="tp-tile__arrow">' . tp_icon( 'arrow', 16 ) . '</span>' : ''
	);
}
